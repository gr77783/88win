# GR777 Frontend
React + Tailwind app.